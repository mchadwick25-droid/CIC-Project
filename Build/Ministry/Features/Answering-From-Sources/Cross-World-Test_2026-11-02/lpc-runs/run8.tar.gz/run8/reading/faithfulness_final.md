# Faithfulness read: lpc story tellings (short / medium / long)

Branch claude/engine-stage3-proof. Read-only. Every cited vendored span was opened, with markup stripped: anf05 lines 30528-30750, 27520-27526, 27661, 27815-27849, 28161-28303, 32346-32375, 36006-36090, 37409-37571, 46695-46728; knopf 4877-4958; possidius 3982-4150 and 4916-5061; prosper 54200-54212.

## Summary

| Story | Short | Medium | Long | T1 | T2 | T3 |
|---|---|---|---|---|---|---|
| celerinus-writes-to-lucian | faithful (97 w) | faithful, T3 (184 w) | faithful, T3 (613 w) | 0 | 0 | 3 |
| election-of-cyprian | **T1** (103 w) | faithful (183 w) | **T1** (440 w) | 2 | 0 | 1 |
| hundred-thousand-sesterces | faithful (98 w) | faithful (181 w) | faithful (455 w) | 0 | 0 | 0 |
| numidicus | faithful, T3 (103 w) | faithful (182 w) | faithful (271 w) | 0 | 0 | 1 |
| the-death-of-cyprian | faithful, T3 (99 w) | faithful, T3 (184 w) | faithful, T3 (612 w) | 0 | 0 | 4 |
| the-plague-and-the-enemies | faithful, T3 (97 w) | faithful, T3 (177 w) | faithful, T3 (487 w) | 0 | 0 | 2 |
| the-psalms-on-the-wall | faithful, T3 (100 w) | faithful (180 w) | faithful (555 w) | 0 | 0 | 1 |

Totals: Tier 1 = 2 (both in election-of-cyprian), Tier 2 = 0, Tier 3 = 12.

---

## 1. celerinus-writes-to-lucian

- **Short (97 w): faithful.** All five essential events are there, in order, with the right speaker. The condition is kept. Nothing says Candida sacrificed.
- **Medium (184 w): faithful, with 2 Tier 3 findings.**
  - T3-1 (test b, craft). The first event drops the prison. The telling has "wrote to Lucian, another confessor." The event line is "wrote to Lucian, another confessor in prison." The prison comes back later ("Lucian answered from prison"), so nothing is lost.
  - T3-2 (test d). The telling has "grieving over so great a crime. Though they were to die there of hunger and thirst". The crime is never tied to the women, and "they" is never tied to the confessors. A first-time listener cannot tell whose crime it was or who was going to die.
- **Long (613 w): faithful, with 1 Tier 3 finding.** Every addition traces to Ep. XX/XXI or to the ANF headings and notes inside the cited span: Rome, the Carthaginian confessors, the clergy's order to wait for a bishop, Statius and Severianus, the harbour, the sixty-five, Paulus's words, and "in a few days".
  - T3-3 (attribution). The telling has "Lucian said, his words had driven back the emperor himself." Lucian wrote "frightened back the great serpent himself, the pioneer of Antichrist". "The emperor Decius" is the ANF editor's note. The content is supported, but the telling gives the editor's gloss as Lucian's own words.

## 2. election-of-cyprian

- **Short (103 w): Tier 1, 1 finding.**
  - T1-1 (test a). The telling has "a crowd of believers surrounded his house." Pontius SS5 has "A crowded fraternity was besieging the doors of the house". He never says whose house it was. The medium and long tellings correctly say "the house where he was". All the essential events are present.
- **Medium (183 w): faithful.** All four essential events are kept in order. The Inferential-Thin relation is marked "In our own reading".
- **Long (440 w): Tier 1, 1 finding, plus 1 Tier 3.**
  - T1-2 (tests a and c). The telling has "untaught in the spiritual life, and he held no office yet." The cited SS5 is figurative: "although not yet resplendent with the glitter of office, but only of hope, he gave promise of entire trustworthiness for the priesthood that was coming upon him". The telling turns that into a flat statement of fact, and Pontius contradicts it. In SS3-4 of the same file, just before the cited span, he writes "he immediately received the presbyterate" and "many things which now as a presbyter he did". So Cyprian was already a presbyter. Fix: drop "and he held no office yet", or say "he had not yet become bishop".
  - T3-4 (test c, slight). The telling has "he already seemed completely trustworthy for the office ahead of him." The source has "gave promise of entire trustworthiness". The promise has become an appearance he already had.
  - Everything else is supported by SS5, Ep. XXXIX and Ep. LXVII: the window, the people on fire, the future martyr, the forgiven opponents, the 251 plot to keep him away, and "had watched his conduct".

## 3. hundred-thousand-sesterces

- **Short (98 w): faithful.** All four essential events are present. "Gave quickly and freely" matches "promptly and willingly and liberally". There is no currency conversion.
- **Medium (181 w): faithful.** "Christ let this happen to test our faith" matches Ep. LIX SS2, "who suffers these things to happen ... that our faith may be tried".
- **Long (455 w): faithful.** The temple of God, the cross and blood, the fathers and husbands, the virgins (told as being "in danger", which matches "lest ... should be sullied"), the sick and the captive in the Gospel, and the fruitful fields are all in SS1-3.

## 4. numidicus

- **Short (103 w): faithful, with 1 Tier 3 finding.**
  - T3-5 (test b, partial). The essential event "He was found half dead, pulled out and revived" becomes "he was found alive and revived". "Pulled out" is gone, and "half dead" has softened to "alive". Nothing in it is false. The variant reading and the reason for his survival are kept.
- **Medium (182 w): faithful.** All nine essential events are present, in order.
- **Long (271 w): faithful.** "Some of our presbyters had fallen away ... make up their number with honoured priests" matches "adorn with glorious priests the number of our presbyters that had been desolated by the lapse of some".

## 5. the-death-of-cyprian

- **Short (99 w): faithful, with 2 Tier 3 findings.**
  - T3-6 (test b, partial). The essential event "executed on 14 September 258" loses its year. The essential event "standard-bearer of the sect and an enemy of the gods" is cut to "Sentenced as an enemy of the gods". The medium telling also has no year.
  - T3-7 (test d). The telling has "a life by his deacon Pontius, and the Acta." The Acta is never explained. The essential event says "a Christian compilation built around the records of his hearings".
  - The cloths difference is stated and left unresolved, as the claim guard requires.
- **Medium (184 w): faithful, with 1 Tier 3 finding.** The power from above is told as Pontius's account ("In Pontius ..."), as the claim guard requires.
  - T3-8 (attribution, test a). The telling has "the believers cried out to be beheaded with him. Pontius calls them blessed for sharing their bishop's suffering by speaking out." The cry is in the Acta only ("turba fratrum dicebat: Et nos cum ipso decollemur"). Pontius's "O blessed people ... in outspoken words, suffered with such a bishop" comes after the execution, in SS18. The telling hangs Pontius's blessing on an event that only the Acta reports. The same pattern is in the long telling.
- **Long (612 w): faithful, with 1 Tier 3 finding plus the T3-8 pattern.** Everything else checks against Pontius SS15-18 or Acta I-V: the gardens, the officer's house, the young women, the bright day, the sweat, the officer who had been a Christian, "Tu es Thascius Cyprianus", "Non facio", "in re tam iusta nulla est consultatio", the council, the tablet, the tunic, the linen, and the twenty-five gold pieces.
  - T3-9 (wording and attribution). The telling has "his blood would uphold the law". Pontius has "with his blood discipline would begin to be established", and the Acta has "sanguine tuo sancietur disciplina". "The law" is an interpretive rendering. Separately, the Acta-only details (the young women, the crowd at Sextus's place) are not marked as Acta, though the record promises "We say which text tells each part."

## 6. the-plague-and-the-enemies

- **Short (97 w): faithful, with 1 Tier 3 finding.**
  - T3-10 (test b, partial). Parts of three essential events are dropped:
    - the corpses lying about the city ("corpses lay all over the city");
    - "as God gives sun and rain beyond His own people";
    - "The poor gave their labour".
  - The core of each event is kept.
- **Medium (177 w): faithful.**
- **Long (487 w): faithful.** The De Mortalitate paragraph is attributed ("our bishop also wrote to us") and matches DM 1-2. The details about Tobias are in Pontius SS10: "incomparable benevolence", "forgive, and forgive again", and "before Christ ... after Christ".
- T3-11 (test c, borderline, all three tellings). Only the Tobias line is attributed to Pontius. The sermon and the relief are told as our own plain memory. The record's divergence_note says the content "reaches us only through Pontius". The heart says "Pontius says that ...". The emic register softens this, but a listener does not hear that the account is Pontius's.

## 7. the-psalms-on-the-wall

- **Short (100 w): faithful, with 1 Tier 3 finding.**
  - T3-12 (test b, order). The essential events are reordered. The record runs: Possidius present at the end, then the teaching, then the psalms. The short runs: the teaching, then the siege, then "Possidius ... was with him to the end", then the psalms. The story is not changed.
- **Medium (180 w): faithful.** All three essential events are present. Possidius's presence is carried by "his friends, Possidius among them, stood by".
- **Long (555 w): faithful.** Each detail checks against its source:
  - Possidius SS28-29: the Vandals, Alans and Goths; Boniface; fourteen months; the sea blockade; "Righteous art thou"; the prayer at table; the third month.
  - Possidius SS31: seventy-six years; "almost forty" as priest or bishop; the funeral service; "repeatedly ordered".
  - Prosper a. 430: "V. kl. Sept." (28 August), answering Julian "inter impetus obsidentium Vandalorum".

## Action list
1. election-of-cyprian, long: remove or reword "and he held no office yet" (T1-2).
2. election-of-cyprian, short: change "surrounded his house" to "surrounded the house where he was" (T1-1).
3. Tier 3 items are optional craft fixes. The ones most worth doing are T3-7 (say what the Acta is in the death short), T3-8 (don't hang Pontius's blessing on the Acta's cry), and T3-2 (the ambiguous "they" and "crime" in the celerinus medium).
