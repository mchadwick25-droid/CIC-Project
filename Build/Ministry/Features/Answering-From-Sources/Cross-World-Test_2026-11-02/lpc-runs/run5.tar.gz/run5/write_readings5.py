import json
D='/tmp/claude-0/-home-user-CIC-Project/2ab74c4e-7851-59d0-9565-8d304744fbed/scratchpad/run5/reading/'
R=[]
def r(id,t1=[],t2=[],t3=[],depth='adequate',aq='yes',eco='ok',serious=None,fs=None,handled=None):
    o=dict(id=id,tier1=[dict(sentence=s,why=w) for s,w in t1],tier2=[dict(sentence=s,why=w) for s,w in t2],
           tier3=[dict(sentence=s,why=w) for s,w in t3],depth=depth,addresses_question=aq,ecology=eco,
           serious=bool(t1) or bool(serious))
    if fs is not None: o['false_silence']=fs
    if handled is not None: o['handled']=handled
    R.append(o)
r('q006',
  t2=[("Augustine taught as well that the punishment of the lost has no end, and Augustine said God's mercy is shown in easing the torments of the lost, not in ending the torments.",
       "Wrong force. In Enchiridion 112 (npnf103, lines 23632-23641) the easing is a supposition Augustine allows the doubters ('let them suppose, if the thought gives them pleasure'). He does not teach it. The answer gives it as his own teaching on God's mercy. The record's tensions field says 'He let the doubters suppose', but the sentence drops that.")],
  t3=[("Cyprian and Cyprian's colleagues ... Paul's thorn is Augustine's example ... the confession of the Holy Ghost completes the Trinity",
       "Repeated names where a pronoun belongs; the rewrite reads mechanically."),
      ("whole answer","The answer lists doctrines (Trinity, infant grace, Paul's thorn, endless punishment) without saying what kind of God this is. Grace, the most characteristic theme (lpc.term.grace, the Sermon 78 quote), was cited in the draft and then dropped.")],
  depth='adequate',aq='partly',serious=True,
  handled="Sealed probe: partly. The Trinity and mercy content is grounded, but the endless-punishment sentence turns a supposition into teaching.")
r('q010',
  t3=[("Cyprian held that nothing counts as apostolic unless it is written in the Gospel or the apostles' own letters...",
       "Leaves out that Cyprian aimed this test at the tradition Stephen of Rome claimed. The not_for of lpc.witness.tradition-tested-by-apostolic-warrant warns against reading it as covering every custom."),
      ("whole answer","Answers 'authority' (it repeats the q012 material) rather than the 'approach and purpose' of reading. Nothing on preaching, the reading as 'daily bread' (lpc.quote.the-sermon-and-the-readings-are-daily-bread) or On Christian Doctrine (on the shelf). The Genesis sentences repeat 'the first three days of Genesis' twice.")],
  depth='adequate',aq='partly',
  handled="Sealed probe: partly. Every claim is grounded, but the answer meets the authority half of the cell, not reading's purpose.")
r('q012',
  t3=[("whole answer","The long inserted On Baptism II.3.4 quote repeats the paraphrase just before it. The 256 'no bishop over another' sentence stands without a link to Scripture's authority.")],
  depth='rich',aq='yes',
  handled="Sealed probe: handled rightly. It qualifies 'sole authority' as the record requires and keeps the two bishops' disputes apart.")
r('q016',
  t3=[("whole answer","Short, and a stray leading space. 'That is the tradition we can set before you' points back at a single sentence about the flock, so it is thin.")],
  depth='adequate',aq='yes',
  handled="Sealed probe: handled rightly. It holds the 430 boundary and does not judge any modern church. The continuity claim comes from world_core (lines 108-109).")
r('q019',
  t3=[("He said in one sentence that the heart is restless for God.",
       "Leaves out the half that answers the question: 'till they find rest in Thee' (Confessions I.1, in the record). The answer names the condition but offers no rest."),
      ("Augustine also taught that the life we lead here is modelled on Christ's death, burial and rising.",
       "Not linked to an unsettled mind. No practice (prayer, the psalms, catechesis) is offered, though the question asks what practice offers.")],
  depth='thin',aq='partly',
  handled="Sealed probe: partly. Grounded, but thin, and it never says what the practice offers.")
r('q021',
  t2=[("What remains of our gathering place comes to us in a letter, not out of the ground. ... So the evidence is unexcavated, not empty.",
       "Widened beyond its source, and contradicted by the shelf. world_core says only that this build has not read the site reports, and that this one piece of evidence comes 'from a letter, not a trench'. The answer makes that a claim about all remains. Mesnage, Afrique chretienne (1912, on the shelf, lines 1668-1891), describes excavated basilicas at Carthage, including churches tied to Cyprian (Gauckler's excavations). A participant would wrongly conclude that nothing survives in the ground. The root is the world_core wording 'unexcavated'.")],
  t3=[("Site reports and inscription collections for our region exist, but none has yet been read for what it shows of our worship.",
       "Build-process narration spoken in the world's voice.")],
  depth='adequate',aq='partly',eco='slip',serious=True,
  handled="Sealed probe: not handled rightly. The Letter CXXVI detail is accurate (npnf101, lines 44461-44560), but the framing denies ground evidence that the shelf records.")
r('q022',
  t3=[("whole answer","Does not describe a day. The rewrite dropped the limit sentence ('A typical day among us is not ours to give you'), so Monica's deathbed request and the infant-baptism ruling stand unframed. 'Ask us what was decided about a person ... we will not run short' now dangles. Preaching, the daily readings and the Lord's Prayer were the nearest day-shaped material, and none is used."),
      ("Cyprian and his colleagues met in council, sixty-six in number, and wrote to Fidus, and Fidus had thought a child should not be baptized before the eighth day.","Awkward run-on with a repeated name.")],
  depth='thin',aq='no',
  handled="Sealed probe: not handled rightly. Nothing is false, but the honest-limit frame was lost and the content does not meet the question.")
r('q023',
  t3=[("whole answer","Gives what the Decian demand cost and the ransom gift, not what belonging cost. It gives no date (250). Renunciation at baptism, catechesis and martyrdom are not used."),
      ("Cyprian wrote that when the flock is wounded, the shepherd is wounded most.","Non sequitur between the lapsed and the ransom."),
      ("The Decian persecution felt less like an attack from outside than like a table emptied one certificate at a time.","An etic metaphor from the force record, spoken as felt experience; no source says how it felt.")],
  depth='adequate',aq='partly',
  handled="Sealed probe: partly. Grounded; it answers an adjacent question.")
r('q102',
  t3=[("whole answer","Abstained. Augustine, Letter XLVII to Publicola, section 5 (npnf101, line 29215), answers directly: 'As to killing others in order to defend one's own life, I do not approve of this, unless one happen to be a soldier or public functionary acting ... in defence of others.'")],
  depth='flat',aq='no',fs=True,
  handled="Fit trap: partly. It avoided placing the turn-the-other-cheek quote, which does not answer self-defence, but the shelf held the direct answer.")
r('q103',
  t3=[("whole answer","Bare quote. It does not say this is Augustine at Hippo in 430, with the city under siege, or that Possidius was his friend. The penitential psalms on the wall (lpc.story.the-psalms-on-the-wall), which show the peace of his end, are not used.")],
  depth='thin',aq='yes',
  handled="Fit trap: handled rightly. The placed quote (Possidius, Life XXXI: sight and hearing unimpaired, friends praying, 'slept with his fathers') does answer the ask.")
r('q038',
  t3=[("whole answer","The quote's 'he' is Paul (Romans 5:5). The record's claim guard says the speaker must name him, and the answer does not. lpc.quote.love-and-do-what-thou-wilt, the line on love most likely meant by 'famous', exists but was not retrieved.")],
  depth='adequate',aq='yes')
r('q039',depth='adequate',aq='yes')
r('q040',
  t3=[("whole answer","No context. It does not say Cyprian wrote this to Demetrianus, a pagan persecutor, or that 'there' means after death.")],
  depth='adequate',aq='yes')
r('q042',
  t3=[("whole answer","Asked for a line to read; gave a description of catechesis and a question back. lpc.quote.let-your-creed-be-a-mirror (Sermon 58.13: 'Let your Creed be like a mirror to you ... the daily clothing of your mind') is exactly that line and was used in q070. Retrieval miss.")],
  depth='thin',aq='partly')
r('q043',
  t3=[("whole answer","Abstained after a failed read. The draft placed lpc.quote.let-us-too-be-beheaded-with-him (Acta: 'Let us be beheaded with him too'), backed by lpc.story.the-death-of-cyprian, and it answers the question exactly.")],
  depth='flat',aq='no',fs=True)
r('q046',depth='rich',aq='yes')
r('q058',
  t3=[("Pontius says he bound them himself.","'He' is ambiguous (Pontius or Cyprian). The record says Cyprian bound his own eyes."),
      ("whole answer","Leaves out the kneeling prayer and the twenty-five gold pieces for the executioner, which the story holds.")],
  depth='rich',aq='yes')
r('q060',depth='rich',aq='yes')
r('q063',
  t3=[("whole answer","Keeps the 430 boundary and reports City of God XI.7 and XII.10 accurately. Set beside 'evolution', though, the 6,000-year reckoning invites the reader to place Augustine in the modern debate, which the not_for of lpc.witness.days-before-the-sun warns against. A sentence saying the question lies after our years and is not his would close that.")],
  depth='adequate',aq='partly')
r('q065',
  t3=[("whole answer","Thin. It lists letter numbers but says nothing of what women did or held among us (virgins, widows, Monica, Cyprian's On the Dress of Virgins on the shelf), so 'women pastors' is met only by the 'elite, male and clerical' note.")],
  depth='thin',aq='partly')
r('q070',
  t3=[("Augustine spoke to candidates for baptism about the Creed:","The record's not_for warns that the sermon (Sermon 58) is on the Lord's Prayer, not the Creed. The passage does speak of the Creed, but the lead-in should not imply that is the sermon's subject.")],
  depth='adequate',aq='yes')
r('q072',
  t2=[("Each bishop judges for himself, and only Christ judges him.",
       "Scope slip. lpc.term.bishop-of-bishops is the rule stated at the council of 256 (years 256-256). Here it opens an answer to 'Did you have a pope?' with no date, as the whole world's stance. The term's not_for forbids reading it as an anti-papal manifesto, and Augustine held regional councils yield to plenary ones.")],
  t3=[("whole answer","The rewrite dropped Augustine's list of Roman bishops back to Linus, which shows what Rome meant to him. It does not use Cyprian's quarrel with Stephen of Rome or the contested De Unitate primacy text.")],
  depth='thin',aq='partly',eco='slip')
r('q074',
  t3=[("whole answer","Abstained. world_core's 430 boundary answers this plainly: Islam comes after our years, so our people never met yours. The draft began that way. Silence leaves a sincere question unmet.")],
  depth='flat',aq='no',fs=True)
r('q075',
  t2=[("Cyprian said that every bishop has his own proper right of judgment. At the council of 256, Cyprian said we judge no one...",
       "Wrong force by placement. The rewrite dropped the 'we say nothing of any church after us' frame, so 256 rules on bishops' independence stand as the answer to 'the pope today'. That reads them as an anti-papal verdict across sixteen centuries, which lpc.term.bishop-of-bishops' not_for forbids.")],
  t3=[("whole answer","Disjointed. 'Augustine never once put Cyprian outside our communion' has lost the sentence saying Augustine judged the ruling wrong. The separations sentence arrives unexplained.")],
  depth='thin',aq='partly',eco='slip')
r('q080',
  t2=[("Between Cyprian's death in 258 and Augustine's ordination in 391, we have no pastor's words of our own to give you.",
       "Widened beyond its source's hedge. lpc.limit.the-silent-century says 'as far as we have weighed it'. Optatus of Milevis, a Catholic African bishop writing c. 367, is on the lpc shelf (optatus_against-the-donatists.txt; PL 11), and so are the African councils of the 340s and 390 (Codex canonum). A flat 'no words' misstates what survives.")],
  t3=[("Nine tractatus in Morin's edition of 1917 are not yet assessed, so we lean on none of the nine tractatus.","Build-process jargon in the voice."),
      ("whole answer","A list of limits. It never says the plain thing: quotes are verbatim and the rest is grounded in the records.")],
  depth='adequate',aq='partly',eco='slip')
r('q081',
  t3=[("whole answer","Abstained after a failed read. The draft held the line without caving: Cyprian's 'no salvation out of the Church' (lpc.quote.no-salvation-out-of-the-church, lpc.witness.no-salvation-outside-the-church), set beside the unsettled baptism question between the two bishops (lpc.term.heresy, lpc.witness.communion-over-separation).")],
  depth='flat',aq='no',fs=True)
r('q086',depth='thin',aq='yes')
r('q096',
  t3=[("whole answer","The rewrite dropped the framing (the record keeps no one's favourite; 'the story our record holds most plainly'). Paul's thorn arrives unframed and the wars of Moses are tacked on. 'Augustine' is repeated five times in place of 'he'.")],
  depth='adequate',aq='partly')
r('q099',
  t3=[("whole answer","Answers 'eyewitness to the risen Jesus', not 'did you see miracles'. City of God XXII.8 (npnf102, on the shelf) has Augustine report healings at Hippo and Carthage that he saw himself (Innocentius, 'under my own eyes'). Shelf miss.")],
  depth='thin',aq='partly')
r('q100',
  t3=[("whole answer","Abstained after a failed read. The draft had the no-chain-of-witnesses limit and the Pontius-only plague framing. City of God XXII.8 (shelf) gives Augustine's own case for present miracles, and lpc.story.the-death-of-cyprian models the 'only how Pontius tells it' handling.")],
  depth='flat',aq='no',fs=True)
d=json.load(open(D+'sample.json'))
order=[it['id'] for it in d['items']]; grp={it['id']:it['group'] for it in d['items']}
m={x['id']:x for x in R}; assert set(m)==set(order),(set(order)-set(m),set(m)-set(order))
L=[m[i] for i in order]
for x in L: x['group']=grp[x['id']]; x['stratum']='sealed' if grp[x['id']]=='A' else ('fit_trap' if grp[x['id']]=='K' else 'other')
json.dump(L,open(D+'readings.json','w'),indent=1,ensure_ascii=False)
from collections import Counter
for s in ['all','sealed','fit_trap','other']:
    rs=[x for x in L if s=='all' or x['stratum']==s]
    print(s,len(rs),'t1',sum(bool(x['tier1']) for x in rs),'t2',sum(bool(x['tier2']) for x in rs),'t3',sum(bool(x['tier3']) for x in rs),
      dict(Counter(x['depth'] for x in rs)),dict(Counter(x['addresses_question'] for x in rs)),'eco',sum(x['ecology']=='slip' for x in rs),
      'serious',sum(x['serious'] for x in rs),'abst',sum('false_silence' in x for x in rs),'fs',sum(x.get('false_silence',False) for x in rs))
