import json
R=[]
def a(id,t3,depth,addr,t2=None,fs=False,eco="ok"):
    R.append(dict(id=id,tier1=[],tier2=t2 or [],tier3=t3,depth=depth,addresses_question=addr,ecology=eco,serious=False,false_silence=fs))
a("q001",["Last sentence (pattern of Christ's life) is loosely attached to the question of transmission."],"adequate","yes")
a("q002",[],"adequate","yes")
a("q010",["Answers authority more than 'approach and purpose' of reading; no purpose of reading given.","Cyprian's apostolic-writing test given without its context (aimed at Stephen's claimed tradition) and without Augustine's contrasting test from the same record.","Repetitive 'Augustine wrote...' run of sentences."],"adequate","partly")
a("q012",["Duplicated lead-in: 'In today's English, Augustine says. In today's English, Augustine says:'.","Very long inserted quote dominates; confessor sentence tacked on without transition."],"adequate","yes")
a("q015",["Reads the question as members who failed, not the community failing someone; does not take up the community's own failure."],"adequate","partly")
a("q019",["Thin: one quoted line and a question back; no practice offered (prayer, psalms, catechesis)."],"thin","partly")
a("q020",[],"rich","yes")
a("q023",["Gives what the Decian demand cost, not what belonging cost; Numidicus, martyrdom, baptismal renunciation not used."],"thin","partly")
a("q026",[],"adequate","yes")
a("q027",["Clarifying question or catechesis (De catechizandis rudibus, lpc.term.catechesis) would have served better than bare abstention."],"flat","no")
a("q033",["Does not explain why Ignatius, Irenaeus, Athanasius, Clement are absent (Greek/East, other centuries); only Augustine and Tertullian addressed."],"adequate","partly")
a("q036",["Abstained although many verbatim quote records exist (e.g. restless heart, lpc.quote.love-and-do-what-thou-wilt, lpc.quote.ye-belong-to-my-care)."],"flat","no",fs=True)
a("q037",[],"rich","yes")
a("q039",[],"adequate","yes")
a("q048",[],"rich","yes")
a("q051",["Repetitive structure: summary line, a dangling colon lead-in, then the telling restarts ('Our deacon Pontius wrote...')."],"rich","yes")
a("q057",["Opening is redundant and contains a fragment ('Two early texts tell the death... and where the two texts differ.'); date stated twice.","'Pontius says he bound them himself' leaves 'he' ambiguous (Cyprian)."],"rich","yes")
a("q060",["Long Pontius quote appended after the close repeats the telling; Tobias lines distract."],"rich","yes")
a("q065",["Lists letter numbers rather than saying what the record shows of women's roles or of who held office; thin redirect."],"thin","partly")
a("q068",["Abstained though honest_limit records answer it directly: lpc.limit.womens-own-voice, lpc.limit.the-lapsed-own-account, lpc.limit.rural-punic-berber-life, lpc.limit.ordinary-interior-life, lpc.limit.the-outsiders-own-view, plus world_core's two-voice imbalance."],"flat","no",fs=True)
a("q072",["Does not use the Cyprian-Stephen quarrel with Rome that the records carry, so 'what Rome meant' is answered only through Augustine's succession list."],"adequate","partly",
  t2=[{"sentence":"Among us no bishop stood over another, and each bishop judged for himself with only Christ to judge him.","why":"lpc.term.bishop-of-bishops is the rule stated at the council of 256 (years 256-256); the answer widens it to the whole world 246-430 and sets it up as an anti-papal answer, which the term's not_for forbids; Augustine held regional councils yield to plenary ones."}],eco="slip")
a("q075",[],"flat","no")
a("q080",["Answers only with the silent-century limit; does not say how much of the earlier answer was sourced versus filled in."],"thin","partly")
a("q084",["Does not read John 1 at all; repeats the Trinity confession. Augustine's Tractates on John (npnf107, Latin tractatus on shelf; lpc.source.augustine-tractates-on-john-and-related-exegesis) were the obvious retrieval."],"thin","no")
a("q085",["Retrieval miss: never touches Matthew 7 or 'I never knew you'; gives certificate/confessor material and asks a question back."],"thin","partly")
a("q086",[],"adequate","yes")
a("q099",["Shelf miss: City of God XXII.8 has Augustine saying the cure of Innocentius at Carthage happened 'in my presence, and under my own eyes' (npnf102, ~line 45679); the answer only gives the ordinary-believer limit and a question back."],"thin","partly")
a("q100",["Bare clarifying question; nothing on how the bishops themselves set down wonders."],"flat","partly")
a("q102",["Abstained though shelf answers it: Augustine, Letter XLVII to Publicola sec. 5 (npnf101 and CSEL34): 'As to killing others in order to defend one's own life, I do not approve of this, unless one happen to be a soldier or public functionary'. lpc.quote.many-have-learned-to-offer-the-other-cheek is related but its guard bars it as a self-defence ruling."],"flat","no",fs=True)
a("q104",["Bare clarifying question; the death-of-Cyprian story (Acta: he had twenty-five gold pieces given to his executioner) was available, with honest limits, as the nearest example."],"flat","partly")
json.dump(R,open('/tmp/claude-0/-home-user-CIC-Project/2ab74c4e-7851-59d0-9565-8d304744fbed/scratchpad/run4/reading/readings.json','w'),indent=1)
s=json.load(open('sample.json')); ab={x['id']:x['was_abstained'] for x in s}
from collections import Counter
for grp,f in [("all",lambda r:True),("was_abs",lambda r:ab[r['id']])]:
    rs=[r for r in R if f(r)]
    print(grp,len(rs),"t1",sum(bool(r['tier1']) for r in rs),"t2",sum(bool(r['tier2']) for r in rs),"t3",sum(bool(r['tier3']) for r in rs),Counter(r['depth'] for r in rs),Counter(r['addresses_question'] for r in rs))
